import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, User } from '../types';
import { 
  authService, 
  cartService, 
  wishlistService, 
  recentlyViewedService 
} from '../services/api';

interface AppContextType {
  user: User | null;
  cart: CartItem[];
  wishlist: Product[];
  recentlyViewed: Product[];
  darkMode: boolean;
  quickViewProduct: Product | null;
  showQuickView: boolean;
  isLoading: boolean;
  cartQuantity: number;
  cartTotal: number;
  openQuickView: (product: Product) => void;
  closeQuickView: () => void;
  setThemeMode: (dark: boolean) => void;
  login: (email: string, pass: string) => Promise<void>;
  register: (email: string, fname: string, lname: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  addToCart: (product: Product, color: string, size: string, quantity?: number) => Promise<void>;
  removeFromCart: (itemId: number) => Promise<void>;
  updateCartQuantity: (itemId: number, quantity: number) => Promise<void>;
  toggleWishlist: (product: Product) => Promise<void>;
  clearCart: () => void;
  viewProduct: (product: Product) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([]);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [showQuickView, setShowQuickView] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Load initial state
  useEffect(() => {
    const initApp = async () => {
      try {
        // Load Dark Mode preference
        const savedDark = localStorage.getItem('aura_dark_mode') === 'true';
        setDarkMode(savedDark);
        if (savedDark) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }

        // Get user session if any
        try {
          const profile = await authService.getProfile();
          setUser(profile);
        } catch (e) {
          console.log('No user session found');
        }

        // Fetch Cart & Wishlist & Recently Viewed
        const c = await cartService.getCart();
        const w = await wishlistService.getWishlist();
        const r = recentlyViewedService.getViewed();

        setCart(c);
        setWishlist(w);
        setRecentlyViewed(r);
      } catch (err) {
        console.error('Failed to initialize App Context:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initApp();

    // Event listeners to handle synced updates across components/actions
    const handleCartSync = async () => {
      const c = await cartService.getCart();
      setCart(c);
    };

    const handleWishlistSync = async () => {
      const w = await wishlistService.getWishlist();
      setWishlist(w);
    };

    const handleViewedSync = () => {
      setRecentlyViewed(recentlyViewedService.getViewed());
    };

    window.addEventListener('aura_cart_updated', handleCartSync);
    window.addEventListener('aura_wishlist_updated', handleWishlistSync);
    window.addEventListener('aura_recently_viewed_updated', handleViewedSync);

    return () => {
      window.removeEventListener('aura_cart_updated', handleCartSync);
      window.removeEventListener('aura_wishlist_updated', handleWishlistSync);
      window.removeEventListener('aura_recently_viewed_updated', handleViewedSync);
    };
  }, []);

  const setThemeMode = (dark: boolean) => {
    setDarkMode(dark);
    localStorage.setItem('aura_dark_mode', String(dark));
    if (dark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const openQuickView = (product: Product) => {
    setQuickViewProduct(product);
    setShowQuickView(true);
  };

  const closeQuickView = () => {
    setShowQuickView(false);
    setTimeout(() => setQuickViewProduct(null), 300); // Wait for animations to finish
  };

  const login = async (email: string, pass: string) => {
    const data = await authService.login(email, pass);
    setUser(data.user);
  };

  const register = async (email: string, fname: string, lname: string, pass: string) => {
    const registeredUser = await authService.register(email, fname, lname, pass);
    // Auto-login or set user
    await login(email, pass);
  };

  const logout = async () => {
    await authService.logout();
    setUser(null);
  };

  const addToCart = async (product: Product, color: string, size: string, quantity: number = 1) => {
    const updated = await cartService.addToCart(product, color, size, quantity);
    setCart(updated);
  };

  const removeFromCart = async (itemId: number) => {
    const updated = await cartService.removeFromCart(itemId);
    setCart(updated);
  };

  const updateCartQuantity = async (itemId: number, quantity: number) => {
    const updated = await cartService.updateCartQuantity(itemId, quantity);
    setCart(updated);
  };

  const toggleWishlist = async (product: Product) => {
    const updated = await wishlistService.toggleWishlist(product);
    setWishlist(updated);
  };

  const clearCart = () => {
    cartService.clearCart();
    setCart([]);
  };

  const viewProduct = (product: Product) => {
    recentlyViewedService.addViewed(product);
    setRecentlyViewed(recentlyViewedService.getViewed());
  };

  const cartQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return (
    <AppContext.Provider
      value={{
        user,
        cart,
        wishlist,
        recentlyViewed,
        darkMode,
        quickViewProduct,
        showQuickView,
        isLoading,
        cartQuantity,
        cartTotal,
        openQuickView,
        closeQuickView,
        setThemeMode,
        login,
        register,
        logout,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        toggleWishlist,
        clearCart,
        viewProduct,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
